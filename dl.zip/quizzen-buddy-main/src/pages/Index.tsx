
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import QuizGenerator from '@/components/QuizGenerator';
import { cn } from '@/lib/utils';
import { fadeIn, staggerChildren } from '@/lib/animations';
import { Button } from "@/components/ui/button";

const Index = () => {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  
  const handleGetStarted = () => {
    if (isAuthenticated) {
      navigate('/dashboard');
    } else {
      navigate('/auth');
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Header />
      
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 py-8 bg-background">
        <section className={cn("text-center max-w-3xl mx-auto mb-16 bg-background text-foreground p-6 rounded-lg", fadeIn())}>
          <div className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium mb-4">
            Digital Library & Learning Platform
          </div>
          
          <h1 className="text-4xl sm:text-5xl font-bold mb-6 tracking-tight text-foreground">
            Transform Your Learning Experience With Interactive Content
          </h1>
          
          <p className="text-lg text-muted-foreground mb-8 mx-auto max-w-2xl">
            Our digital library provides free access to educational resources across all grade levels, 
            with interactive quizzes and immersive reading experiences.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <Button size="lg" onClick={handleGetStarted}>
              Get Started
            </Button>
            <Button size="lg" variant="outline" onClick={() => navigate('/quiz')}>
              Try Quiz Generator
            </Button>
          </div>
          
          <div className={cn("flex flex-wrap justify-center gap-4 mb-12", staggerChildren())}>
            <div className="flex items-center space-x-2">
              <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Free Educational Books</span>
            </div>
            
            <div className="flex items-center space-x-2">
              <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Interactive Quiz Generation</span>
            </div>
            
            <div className="flex items-center space-x-2">
              <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Immersive Reading Experience</span>
            </div>
          </div>
        </section>
        
        <section className="max-w-5xl mx-auto mb-20 px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className={cn("p-6 rounded-xl bg-white shadow-subtle", fadeIn(100))}>
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
              <h3 className="text-lg font-medium mb-2 text-foreground">Digital Library</h3>
              <p className="text-sm text-muted-foreground">
                Access thousands of educational books organized by grade levels, completely free.
              </p>
            </div>
            
            <div className={cn("p-6 rounded-xl bg-white shadow-subtle", fadeIn(200))}>
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
              </div>
              <h3 className="text-lg font-medium mb-2 text-foreground">Quiz Generator</h3>
              <p className="text-sm text-muted-foreground">
                Create personalized quizzes from any book or your own study materials.
              </p>
            </div>
            
            <div className={cn("p-6 rounded-xl bg-white shadow-subtle", fadeIn(300))}>
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="text-lg font-medium mb-2 text-foreground">Upload Your PDFs</h3>
              <p className="text-sm text-muted-foreground">
                Upload your own books and materials to read with immersive themes.
              </p>
            </div>
          </div>
        </section>
        
        <section className="max-w-6xl mx-auto px-4 mb-20">
          <h2 className="text-3xl font-bold text-center mb-12">Experience Interactive Learning</h2>
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="aspect-video bg-gradient-to-r from-indigo-500 to-purple-600 flex items-center justify-center">
              <div className="text-white text-xl font-medium">Interactive Demo</div>
            </div>
          </div>
        </section>
        
        <QuizGenerator />
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
