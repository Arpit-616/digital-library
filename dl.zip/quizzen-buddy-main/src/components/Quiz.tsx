
import React, { useState } from 'react';
import { Quiz, Question } from '@/lib/quiz';
import { cn } from '@/lib/utils';
import { fadeIn, scaleIn } from '@/lib/animations';

interface QuizProps {
  quiz: Quiz;
  onComplete: (quiz: Quiz) => void;
}

const QuizComponent: React.FC<QuizProps> = ({ quiz, onComplete }) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [isTransitioning, setIsTransitioning] = useState(false);
  
  const currentQuestion = quiz.questions[currentQuestionIndex];
  const totalQuestions = quiz.questions.length;
  const progress = ((currentQuestionIndex + 1) / totalQuestions) * 100;
  
  const handleOptionSelect = (option: string) => {
    setAnswers({
      ...answers,
      [currentQuestion.id]: option
    });
  };
  
  const handleNext = () => {
    if (currentQuestionIndex < totalQuestions - 1) {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
        setIsTransitioning(false);
      }, 300);
    } else {
      // Create completed quiz with user answers
      const completedQuiz: Quiz = {
        ...quiz,
        questions: quiz.questions.map(question => ({
          ...question,
          userAnswer: answers[question.id]
        }))
      };
      
      onComplete(completedQuiz);
    }
  };
  
  const isAnswered = answers[currentQuestion?.id] !== undefined;
  const isLastQuestion = currentQuestionIndex === totalQuestions - 1;
  
  return (
    <div className={cn("w-full max-w-3xl mx-auto py-8", fadeIn(200))}>
      <div className="relative h-1 w-full bg-secondary rounded-full overflow-hidden mb-8">
        <div 
          className="h-full bg-primary transition-all duration-300 ease-out"
          style={{ width: `${progress}%` }}
        />
      </div>
      
      <div className="mb-4 flex justify-between items-center">
        <div className="text-sm font-medium">
          Question {currentQuestionIndex + 1} of {totalQuestions}
        </div>
        <div className="text-sm text-muted-foreground">
          {Math.floor(progress)}% Complete
        </div>
      </div>
      
      <div className={cn(
        "bg-white shadow-subtle rounded-xl p-8 transition-opacity duration-300",
        isTransitioning ? "opacity-0" : "opacity-100"
      )}>
        <h3 className="text-xl font-medium mb-6">{currentQuestion?.text}</h3>
        
        <div className="space-y-3">
          {currentQuestion?.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleOptionSelect(option)}
              className={cn(
                "w-full text-left p-4 rounded-lg border transition-all duration-200",
                "hover:border-primary/30 hover:bg-primary/5",
                "focus:outline-none focus:ring-2 focus:ring-primary/20",
                answers[currentQuestion.id] === option 
                  ? "border-primary bg-primary/5" 
                  : "border-border"
              )}
            >
              <div className="flex items-center">
                <div className={cn(
                  "w-6 h-6 rounded-full mr-3 flex items-center justify-center text-xs font-medium",
                  answers[currentQuestion.id] === option
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground"
                )}>
                  {String.fromCharCode(65 + index)}
                </div>
                <span>{option}</span>
              </div>
            </button>
          ))}
        </div>
        
        <div className="mt-8 flex justify-end">
          <button
            onClick={handleNext}
            disabled={!isAnswered}
            className={cn(
              "px-6 py-2 rounded-lg bg-primary text-primary-foreground font-medium",
              "hover:bg-primary/90 active:bg-primary/80 transition-all",
              "disabled:opacity-50 disabled:pointer-events-none",
              "focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
            )}
          >
            {isLastQuestion ? "Complete Quiz" : "Next Question"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default QuizComponent;
