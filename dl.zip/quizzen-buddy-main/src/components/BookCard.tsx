
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Book } from '@/lib/library';
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { cn } from '@/lib/utils';
import { fadeIn } from '@/lib/animations';
import { Button } from "@/components/ui/button";
import { BookOpen, Star, MusicIcon } from 'lucide-react';

interface BookCardProps {
  book: Book;
  className?: string;
}

const BookCard: React.FC<BookCardProps> = ({ book, className }) => {
  const navigate = useNavigate();
  
  const handleReadClick = () => {
    navigate(`/book/${book.id}`);
  };
  
  return (
    <Card className={cn(
      "overflow-hidden transition-all duration-300 hover:shadow-lg h-full flex flex-col group", 
      fadeIn(),
      "hover:translate-y-[-5px]",
      className
    )}>
      <div 
        className={cn(
          "h-40 flex items-center justify-center relative overflow-hidden", 
          book.theme?.background || "bg-gradient-to-r from-gray-200 to-gray-300"
        )}
      >
        <div className="absolute inset-0 bg-black/5 group-hover:bg-black/0 transition-colors duration-300" />
        
        {book.theme?.musicUrl && (
          <div className="absolute top-2 right-2">
            <MusicIcon className="h-4 w-4 text-white drop-shadow" />
          </div>
        )}
        
        <img 
          src={book.coverImage} 
          alt={book.title}
          className="h-32 w-auto object-cover rounded shadow-md transition-all duration-300 group-hover:scale-110"
        />
      </div>
      
      <CardContent className="flex-1 p-4">
        <h3 className="font-semibold text-lg line-clamp-1 group-hover:text-amber-700 transition-colors">{book.title}</h3>
        <p className="text-sm text-muted-foreground mb-2">by {book.author}</p>
        <div className="flex items-center gap-2 text-xs text-muted-foreground mb-3">
          <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">{book.grade}</span>
          <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">{book.language}</span>
          <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-800">{book.publicationYear}</span>
        </div>
        <p className="text-sm line-clamp-3">{book.description}</p>
      </CardContent>
      
      <CardFooter className="p-4 pt-0">
        <Button 
          onClick={handleReadClick} 
          className="w-full bg-amber-600 hover:bg-amber-700 transition-colors group"
        >
          <BookOpen className="mr-2 h-4 w-4 group-hover:rotate-12 transition-transform" />
          Read Now
        </Button>
      </CardFooter>
    </Card>
  );
};

export default BookCard;
