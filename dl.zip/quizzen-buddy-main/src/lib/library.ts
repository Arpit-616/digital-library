
export interface Book {
  id: string;
  title: string;
  author: string;
  coverImage: string;
  description: string;
  grade: string;
  language: string;
  publicationYear: number;
  pdfUrl?: string;
  isUserUploaded?: boolean;
  theme?: {
    background: string;
    musicUrl?: string;
  };
}

export interface User {
  id: string;
  name: string;
  email: string;
  uploadedBooks: string[]; // Book IDs
  favoriteBooks: string[]; // Book IDs
}

// Mock data for the digital library
export const grades = [
  "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6",
  "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12",
  "Higher Education"
];

export const languages = ["English", "Spanish", "French", "German", "Chinese", "Arabic"];

// Sample books
export const sampleBooks: Book[] = [
  {
    id: "book1",
    title: "The Magic of Science",
    author: "Dr. Emily Johnson",
    coverImage: "/placeholder.svg",
    description: "An introduction to basic scientific concepts for young learners.",
    grade: "Grade 3",
    language: "English",
    publicationYear: 2020,
    theme: {
      background: "bg-gradient-to-r from-blue-300 to-purple-400"
    }
  },
  {
    id: "book2",
    title: "Journey to the Stars",
    author: "Michael Chang",
    coverImage: "/placeholder.svg",
    description: "An exciting adventure through our solar system and beyond.",
    grade: "Grade 5",
    language: "English",
    publicationYear: 2019,
    theme: {
      background: "bg-gradient-to-r from-indigo-500 to-purple-900"
    }
  },
  {
    id: "book3",
    title: "World History: Ancient Civilizations",
    author: "Prof. Sarah Williams",
    coverImage: "/placeholder.svg",
    description: "Explore the wonders of ancient civilizations and their contributions to our world.",
    grade: "Grade 8",
    language: "English",
    publicationYear: 2021,
    theme: {
      background: "bg-gradient-to-r from-amber-200 to-yellow-500"
    }
  },
  {
    id: "book4",
    title: "Advanced Calculus",
    author: "Dr. Robert Chen",
    coverImage: "/placeholder.svg",
    description: "A comprehensive guide to advanced calculus concepts.",
    grade: "Higher Education",
    language: "English",
    publicationYear: 2018,
    theme: {
      background: "bg-gradient-to-r from-emerald-400 to-cyan-500"
    }
  },
  {
    id: "book5",
    title: "Introduction to Literature",
    author: "Elizabeth Parker",
    coverImage: "/placeholder.svg",
    description: "Discover the beauty of classic and contemporary literature.",
    grade: "Grade 10",
    language: "English",
    publicationYear: 2020,
    theme: {
      background: "bg-gradient-to-r from-rose-300 to-pink-500"
    }
  }
];

export function getBooksByGrade(grade: string): Book[] {
  return sampleBooks.filter(book => book.grade === grade);
}

export function searchBooks(query: string): Book[] {
  const lowercaseQuery = query.toLowerCase();
  return sampleBooks.filter(
    book => book.title.toLowerCase().includes(lowercaseQuery) || 
           book.author.toLowerCase().includes(lowercaseQuery)
  );
}

// Mock auth functions
let currentUser: User | null = null;

export function getCurrentUser(): User | null {
  return currentUser;
}

export function login(email: string, password: string): User {
  // Mock login - in a real app, this would verify credentials
  currentUser = {
    id: "user1",
    name: "John Doe",
    email: email,
    uploadedBooks: [],
    favoriteBooks: ["book1", "book3"]
  };
  return currentUser;
}

export function signup(name: string, email: string, password: string): User {
  // Mock signup - in a real app, this would create a new user in the database
  currentUser = {
    id: "user" + Math.floor(Math.random() * 1000),
    name: name,
    email: email,
    uploadedBooks: [],
    favoriteBooks: []
  };
  return currentUser;
}

export function logout(): void {
  currentUser = null;
}

export function uploadBook(book: Omit<Book, 'id'>): Book {
  const newBook: Book = {
    ...book,
    id: `book${Math.floor(Math.random() * 10000)}`,
    isUserUploaded: true
  };
  
  // In a real app, we would add this book to the database
  // For now, let's just pretend we did that
  return newBook;
}
