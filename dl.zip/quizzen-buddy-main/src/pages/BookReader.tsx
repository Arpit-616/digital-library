
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { sampleBooks, Book } from '@/lib/library';
import { useAuth } from '@/contexts/AuthContext';
import { extractPdfContent } from '@/lib/quizOpenAIService';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { cn } from '@/lib/utils';
import { fadeIn } from '@/lib/animations';
import { useToast } from "@/hooks/use-toast";

const BookReader: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  
  const [book, setBook] = useState<Book | null>(null);
  const [content, setContent] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);
  const [fontSize, setFontSize] = useState(16);
  
  // Thematic settings
  const [themeBg, setThemeBg] = useState('bg-white');
  const [themeTextColor, setThemeTextColor] = useState('text-foreground');
  
  useEffect(() => {
    // Redirect if not authenticated
    if (!isAuthenticated) {
      navigate('/auth');
      return;
    }
    
    // Find the book
    const foundBook = sampleBooks.find(b => b.id === id);
    if (!foundBook) {
      toast({
        title: "Book not found",
        description: "The book you're looking for doesn't exist.",
        variant: "destructive",
      });
      navigate('/dashboard');
      return;
    }
    
    setBook(foundBook);
    
    // Set theme based on book
    if (foundBook.theme?.background) {
      setThemeBg(foundBook.theme.background);
    }
    
    // Fetch book content
    const fetchContent = async () => {
      try {
        setIsLoading(true);
        // In a real app, we would fetch the PDF and extract text
        // For now, simulate with a delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Mock content
        const mockPdfContent = await extractPdfContent(new ArrayBuffer(0));
        setContent(mockPdfContent);
      } catch (error) {
        console.error('Error loading book:', error);
        toast({
          title: "Error loading book",
          description: "There was a problem loading the book content.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchContent();
  }, [id, isAuthenticated, navigate, toast]);
  
  const handleFontSizeChange = (value: number[]) => {
    setFontSize(value[0]);
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 w-full">
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        ) : book ? (
          <div className={cn("min-h-screen transition-colors", themeBg)}>
            <div className="max-w-4xl mx-auto px-4 py-8">
              <div className={cn("mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4", fadeIn())}>
                <div>
                  <h1 className={cn("text-3xl font-bold", themeTextColor)}>{book.title}</h1>
                  <p className={cn("text-muted-foreground", themeTextColor)}>{book.author} • {book.publicationYear}</p>
                </div>
                
                <Button variant="outline" onClick={() => navigate('/dashboard')}>
                  Back to Library
                </Button>
              </div>
              
              <div className="bg-white/90 backdrop-blur-sm shadow-lg rounded-lg p-6 mb-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="font-semibold">Reading Settings</h2>
                  
                  <div className="flex items-center gap-2">
                    <span className="text-sm">Font Size:</span>
                    <div className="w-32">
                      <Slider
                        defaultValue={[fontSize]} 
                        min={12} 
                        max={24} 
                        step={1}
                        onValueChange={handleFontSizeChange}
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              <div 
                className={cn(
                  "bg-white/95 backdrop-blur-sm shadow-lg rounded-lg p-8", 
                  fadeIn()
                )}
              >
                <div 
                  className="prose prose-slate max-w-none"
                  style={{ fontSize: `${fontSize}px` }}
                >
                  {content.split('\n\n').map((paragraph, index) => (
                    <p key={index}>{paragraph}</p>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-12">
            <p>Book not found.</p>
          </div>
        )}
      </main>
      
      <Footer />
    </div>
  );
};

export default BookReader;
