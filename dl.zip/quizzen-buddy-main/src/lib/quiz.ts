
export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: string;
  userAnswer?: string;
}

export interface Quiz {
  id: string;
  title: string;
  questions: Question[];
  createdAt: Date;
}

export function generateQuestionsFromText(text: string, count: number = 5): Question[] {
  // This is a mock implementation. In a real application, this would call an AI API
  const questions: Question[] = [];
  
  // Extract sentences from text - very simplified approach
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 10);
  
  // Generate some basic questions based on the text
  for (let i = 0; i < Math.min(count, sentences.length); i++) {
    const sentence = sentences[i].trim();
    if (sentence.length < 15) continue;
    
    // Extract key terms (naive approach)
    const words = sentence.split(' ').filter(w => w.length > 4);
    if (words.length < 3) continue;
    
    // Pick a random "important" word to ask about
    const randomIndex = Math.floor(Math.random() * words.length);
    const keyWord = words[randomIndex];
    
    // Create a question
    const questionText = sentence.replace(keyWord, '________');
    
    // Generate options (including the correct answer)
    const allOptions = [keyWord];
    
    // Add 3 other words from the text as distractors
    const otherWords = words.filter(w => w !== keyWord);
    for (let j = 0; j < 3 && j < otherWords.length; j++) {
      allOptions.push(otherWords[j]);
    }
    
    // Fill in any missing options with generic options
    while (allOptions.length < 4) {
      allOptions.push(`Option ${allOptions.length + 1}`);
    }
    
    // Shuffle the options
    const shuffledOptions = allOptions.sort(() => Math.random() - 0.5);
    
    questions.push({
      id: `q-${i}`,
      text: `What word completes this sentence? "${questionText}"`,
      options: shuffledOptions,
      correctAnswer: keyWord
    });
  }
  
  return questions;
}

export function calculateScore(quiz: Quiz): { score: number; total: number; percentage: number } {
  const total = quiz.questions.length;
  let correct = 0;
  
  quiz.questions.forEach(question => {
    if (question.userAnswer === question.correctAnswer) {
      correct++;
    }
  });
  
  return {
    score: correct,
    total,
    percentage: Math.round((correct / total) * 100)
  };
}

export function generateQuizId(): string {
  return Math.random().toString(36).substring(2, 9);
}
