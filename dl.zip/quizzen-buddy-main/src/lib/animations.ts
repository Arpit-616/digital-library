
import { cn } from "./utils";

export const fadeIn = (delay: number = 0) => 
  cn("opacity-0 animate-fade-in", delay > 0 && `delay-${delay}`);

export const scaleIn = (delay: number = 0) => 
  cn("opacity-0 animate-scale-in", delay > 0 && `delay-${delay}`);

export const slideIn = (delay: number = 0) => 
  cn("translate-x-[-100%] animate-slide-in", delay > 0 && `delay-${delay}`);

export const staggerChildren = (className: string = "") => {
  return cn("stagger-animate", className);
};

export const shimmer = (className: string = "") => {
  return cn(
    "animate-shimmer bg-gradient-to-r from-transparent via-white/20 to-transparent bg-[length:500px_100%]",
    className
  );
};

export const pulseAnimation = (duration: string = "3s") => {
  return cn("animate-pulse-slow", `[animation-duration:${duration}]`);
};

export const floatAnimation = (duration: string = "6s") => {
  return cn("animate-float", `[animation-duration:${duration}]`);
};

export const seasonalBackground = (season: "spring" | "summer" | "autumn" | "winter") => {
  const backgrounds = {
    spring: "bg-gradient-to-br from-green-100 to-yellow-100",
    summer: "bg-gradient-to-br from-amber-50 to-yellow-100",
    autumn: "bg-gradient-to-br from-amber-100 to-orange-100",
    winter: "bg-gradient-to-br from-blue-50 to-indigo-100",
  };
  
  return backgrounds[season];
};
