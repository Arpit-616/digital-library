
import React, { useState, useRef } from 'react';
import { cn } from '@/lib/utils';
import { fadeIn } from '@/lib/animations';
import { processAndGenerateQuiz, extractPdfContent } from '@/lib/quizOpenAIService';
import { useToast } from "@/hooks/use-toast";

interface TextInputProps {
  onSubmit: (text: string) => void;
  className?: string;
  uploadLabel?: string;
  placeholderText?: string;
}

const TextInput: React.FC<TextInputProps> = ({ 
  onSubmit, 
  className,
  uploadLabel = "Upload PDF",
  placeholderText = "Paste your text here... (minimum 100 characters recommended for better results)"
}) => {
  const [text, setText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    
    setIsLoading(true);
    
    // Simulate loading state for UI feedback
    setTimeout(() => {
      onSubmit(text);
      setIsLoading(false);
    }, 1200);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check if the file is a PDF
    if (file.type !== 'application/pdf') {
      toast({
        title: "Invalid file format",
        description: "Please upload a PDF file.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    try {
      toast({
        title: "Processing PDF",
        description: "Extracting text from your PDF...",
      });

      // Read the file content
      const fileContent = await readFileAsArrayBuffer(file);
      
      // Process the PDF and generate a quiz
      const extractedText = await extractPdfContent(fileContent);
      
      // Set the extracted text to the textarea
      setText(extractedText);
      
      toast({
        title: "PDF Processed",
        description: "Text extracted successfully. Review and click Generate Quiz.",
      });
    } catch (error) {
      console.error("Error processing PDF:", error);
      toast({
        title: "Error",
        description: "Failed to process the PDF file. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const readFileAsArrayBuffer = (file: File): Promise<ArrayBuffer> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as ArrayBuffer);
      reader.onerror = reject;
      reader.readAsArrayBuffer(file);
    });
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleTryExample = () => {
    const exampleText = `Artificial Intelligence (AI) refers to the simulation of human intelligence in machines that are programmed to think and learn like humans. The term may also be applied to any machine that exhibits traits associated with a human mind such as learning and problem-solving.

The ideal characteristic of artificial intelligence is its ability to rationalize and take actions that have the best chance of achieving a specific goal. A subset of artificial intelligence is machine learning, which refers to the concept that computer programs can automatically learn from and adapt to new data without being assisted by humans.

Deep learning techniques enable this automatic learning through the absorption of huge amounts of unstructured data such as text, images, or video.`;

    setText(exampleText);
    toast({
      title: "Example Loaded",
      description: "An example text has been loaded. Click Generate Quiz to continue.",
    });
  };

  return (
    <div className={cn("w-full max-w-3xl mx-auto", fadeIn(200), className)}>
      <div className="bg-white shadow-subtle rounded-xl p-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-secondary/50 to-transparent opacity-50 pointer-events-none" />
        
        <h2 className="text-lg font-medium mb-4">Enter your study material</h2>
        <p className="text-sm text-muted-foreground mb-6">
          Paste text from your notes, books, or any study material to generate quiz questions.
        </p>
        
        <form onSubmit={handleSubmit} className="relative z-10">
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={placeholderText}
            className="w-full min-h-[200px] p-4 border rounded-lg resize-y focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary/30 transition-all"
            disabled={isLoading}
          />
          
          <div className="flex items-center justify-between mt-4">
            <p className="text-xs text-muted-foreground">
              {text.length} characters
            </p>
            
            <button
              type="submit"
              disabled={!text.trim() || text.length < 50 || isLoading}
              className={cn(
                "px-6 py-2 rounded-lg bg-primary text-primary-foreground font-medium transition-all",
                "hover:bg-primary/90 active:bg-primary/80",
                "disabled:opacity-50 disabled:pointer-events-none",
                "focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2",
                isLoading && "animate-pulse"
              )}
            >
              {isLoading ? "Generating..." : "Generate Quiz"}
            </button>
          </div>
        </form>
      </div>
      
      <div className="mt-4 p-4 bg-white shadow-subtle rounded-lg flex flex-col space-y-4">
        <h3 className="text-sm font-medium text-foreground">Alternative Input Methods</h3>
        
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".pdf"
            className="hidden"
          />
          <button 
            onClick={handleUploadClick}
            className="w-full sm:w-auto px-4 py-2 border border-primary/20 rounded-lg text-sm font-medium text-primary hover:bg-primary/5 transition-colors flex items-center justify-center gap-2"
            disabled={isLoading}
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            {uploadLabel}
          </button>
          
          <button 
            onClick={handleTryExample}
            className="w-full sm:w-auto px-4 py-2 border border-primary/20 rounded-lg text-sm font-medium text-primary hover:bg-primary/5 transition-colors flex items-center justify-center gap-2"
            disabled={isLoading}
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            Try Example
          </button>
        </div>
      </div>
    </div>
  );
};

export default TextInput;
