
import React from 'react';
import { cn } from '@/lib/utils';

interface FooterProps {
  className?: string;
}

const Footer: React.FC<FooterProps> = ({ className }) => {
  return (
    <footer className={cn("w-full py-6 px-8 mt-12 border-t", className)}>
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center">
        <div className="mb-4 md:mb-0">
          <div className="flex items-center space-x-2">
            <span className="w-6 h-6 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-semibold text-xs">
              Q
            </span>
            <span className="text-sm font-medium">QuizzenBuddy</span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Generate quizzes with AI. Learn smarter.
          </p>
        </div>
        
        <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-8">
          <div>
            <h4 className="font-medium text-sm mb-2">Resources</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-xs text-muted-foreground hover:text-foreground transition-colors">
                  Documentation
                </a>
              </li>
              <li>
                <a href="#" className="text-xs text-muted-foreground hover:text-foreground transition-colors">
                  API
                </a>
              </li>
              <li>
                <a href="#" className="text-xs text-muted-foreground hover:text-foreground transition-colors">
                  Privacy
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium text-sm mb-2">Company</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-xs text-muted-foreground hover:text-foreground transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="#" className="text-xs text-muted-foreground hover:text-foreground transition-colors">
                  Contact
                </a>
              </li>
              <li>
                <a href="#" className="text-xs text-muted-foreground hover:text-foreground transition-colors">
                  Terms
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto mt-8 pt-4 border-t text-center">
        <p className="text-xs text-muted-foreground">
          © {new Date().getFullYear()} QuizzenBuddy. All rights reserved.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
