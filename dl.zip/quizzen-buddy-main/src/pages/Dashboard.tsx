
import React, { useState, useEffect } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { grades, getBooksByGrade, searchBooks, Book } from '@/lib/library';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import BookCard from '@/components/BookCard';
import BookUploadModal from '@/components/BookUploadModal';
import { cn } from '@/lib/utils';
import { fadeIn, staggerChildren, shimmer } from '@/lib/animations';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Leaf, Search, Upload, BookOpen, GraduationCap } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const Dashboard: React.FC = () => {
  const { isAuthenticated, user } = useAuth();
  const [selectedGrade, setSelectedGrade] = useState(grades[0]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [books, setBooks] = useState<Book[]>(getBooksByGrade(grades[0]));
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  // Simulate loading for animation effects
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 800);
    return () => clearTimeout(timer);
  }, []);

  // Redirect if not authenticated
  if (!isAuthenticated) {
    return <Navigate to="/auth" />;
  }

  const handleTabChange = (value: string) => {
    setIsLoading(true);
    setSelectedGrade(value);
    
    // Small delay for loading animation
    setTimeout(() => {
      setBooks(getBooksByGrade(value));
      setSearchQuery('');
      setIsLoading(false);
    }, 400);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Small delay for loading animation
    setTimeout(() => {
      if (searchQuery.trim()) {
        setBooks(searchBooks(searchQuery));
      } else {
        setBooks(getBooksByGrade(selectedGrade));
      }
      setIsLoading(false);
    }, 400);
  };

  const handleBookUploaded = (newBook: Book) => {
    // In a real app, this would come from the backend
    setBooks(prevBooks => [...prevBooks, newBook]);
    setIsUploadModalOpen(false);
    toast({
      title: "Book uploaded successfully!",
      description: `"${newBook.title}" has been added to your library.`,
    });
  };

  // Get the current season
  const getSeason = () => {
    const month = new Date().getMonth();
    if (month >= 2 && month <= 4) return "spring";
    if (month >= 5 && month <= 7) return "summer";
    if (month >= 8 && month <= 10) return "autumn";
    return "winter";
  };
  
  const season = getSeason();
  const seasonColors = {
    spring: "from-green-100 to-yellow-100 bg-gradient-to-br",
    summer: "from-amber-50 to-yellow-100 bg-gradient-to-br",
    autumn: "from-amber-100 to-orange-100 bg-gradient-to-br",
    winter: "from-blue-50 to-indigo-100 bg-gradient-to-br"
  };

  return (
    <div className={`min-h-screen flex flex-col ${seasonColors[season]}`}>
      <Header />
      
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 py-8">
        <section className={cn("mb-8", fadeIn())}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                <GraduationCap className="h-8 w-8 text-amber-600" />
                <span>Welcome, {user?.name}!</span>
              </h1>
              <p className="text-muted-foreground mt-1">Explore our collection of free educational books</p>
            </div>
            
            <Button onClick={() => setIsUploadModalOpen(true)} className="bg-amber-600 hover:bg-amber-700 transition-colors group">
              <Upload className="mr-2 h-4 w-4 group-hover:rotate-12 transition-transform" />
              Upload PDF
            </Button>
          </div>
          
          <form onSubmit={handleSearch} className="flex gap-2 max-w-lg relative">
            <Input
              placeholder="Search by title or author..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 border-amber-200 focus-visible:ring-amber-400"
            />
            <Button type="submit" className="bg-amber-600 hover:bg-amber-700 transition-colors">
              <Search className="mr-2 h-4 w-4" />
              Search
            </Button>
          </form>
        </section>
        
        <Tabs defaultValue={grades[0]} onValueChange={handleTabChange} className="mt-8">
          <TabsList className="mb-6 flex overflow-x-auto pb-2 scrollbar-thin bg-white/50 backdrop-blur-sm rounded-lg border border-amber-200">
            {grades.map((grade) => (
              <TabsTrigger key={grade} value={grade} className="min-w-max data-[state=active]:bg-amber-100 data-[state=active]:text-amber-900">
                {grade}
              </TabsTrigger>
            ))}
          </TabsList>
          
          {grades.map((grade) => (
            <TabsContent key={grade} value={grade} className="mt-0">
              {isLoading ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                    <div key={i} className={cn("h-80 rounded-lg", shimmer("bg-gray-200/60"))}>
                    </div>
                  ))}
                </div>
              ) : (
                <div className={cn("grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6", staggerChildren())}>
                  {books.length > 0 ? (
                    books.map((book) => (
                      <BookCard key={book.id} book={book} />
                    ))
                  ) : (
                    <div className="col-span-full text-center py-12 glass-morphism rounded-lg">
                      <BookOpen className="mx-auto h-12 w-12 text-amber-600 mb-2 opacity-50" />
                      <p className="text-muted-foreground">No books found. Try a different search or grade level.</p>
                    </div>
                  )}
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </main>
      
      {/* Seasonal decoration */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        {season === "autumn" && Array.from({ length: 20 }).map((_, i) => (
          <Leaf 
            key={i}
            className="absolute w-6 h-6 text-amber-500 opacity-30 animate-fall"
            style={{
              left: `${Math.random() * 100}%`,
              top: `-20px`,
              transform: `rotate(${Math.random() * 360}deg)`,
              animationDuration: `${5 + Math.random() * 10}s`,
              animationDelay: `${Math.random() * 5}s`,
            }}
          />
        ))}
      </div>
      
      <BookUploadModal 
        isOpen={isUploadModalOpen} 
        onClose={() => setIsUploadModalOpen(false)}
        onUpload={handleBookUploaded}
      />
      
      <Footer />
    </div>
  );
};

export default Dashboard;
