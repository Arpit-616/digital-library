
import React, { useState, useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import LoginForm from '@/components/LoginForm';
import SignupForm from '@/components/SignupForm';
import { cn } from '@/lib/utils';
import { fadeIn, scaleIn } from '@/lib/animations';
import { Leaf, BookOpen, GraduationCap, School } from 'lucide-react';

const Auth: React.FC = () => {
  const [isLoginView, setIsLoginView] = useState(true);
  const { isAuthenticated } = useAuth();
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    // Animation delay
    const timer = setTimeout(() => {
      setLoaded(true);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  // Redirect if already authenticated
  if (isAuthenticated) {
    return <Navigate to="/dashboard" />;
  }

  // Generate a random rotation angle for the decorative elements
  const randomRotation = () => Math.floor(Math.random() * 360);

  return (
    <div className="min-h-screen bg-gradient-to-r from-amber-100 to-orange-200 flex flex-col overflow-hidden">
      {/* Floating books animation */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <BookOpen className="absolute top-[15%] left-[8%] text-amber-600/20 w-16 h-16 animate-pulse-slow"
          style={{ animationDuration: '7s' }} />
        <GraduationCap className="absolute bottom-[20%] left-[15%] text-amber-700/15 w-20 h-20 animate-pulse-slow"
          style={{ animationDuration: '8s' }} />
        <School className="absolute top-[10%] right-[12%] text-amber-800/20 w-14 h-14 animate-pulse-slow"
          style={{ animationDuration: '10s' }} />
      </div>

      <div className="flex-1 flex items-center justify-center px-4 py-12 relative z-10">
        <div className={cn(
          "w-full max-w-md", 
          loaded ? fadeIn() : "opacity-0"
        )}>
          <div className={cn(
            "text-center mb-8", 
            loaded ? scaleIn() : "opacity-0 scale-90"
          )}>
            <div className="inline-flex items-center gap-3 mb-2">
              <BookOpen className="h-8 w-8 text-amber-800" />
              <h1 className="text-4xl font-bold text-amber-900">Digital Library</h1>
            </div>
            <p className="text-amber-800 mt-2">Your gateway to knowledge</p>
          </div>

          {isLoginView ? (
            <LoginForm onToggleForm={() => setIsLoginView(false)} />
          ) : (
            <SignupForm onToggleForm={() => setIsLoginView(true)} />
          )}
        </div>
      </div>

      {/* Enhanced falling leaves animation */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        {Array.from({ length: 40 }).map((_, i) => (
          <div key={i}>
            <Leaf 
              className="absolute text-amber-500 opacity-20 animate-fall"
              style={{
                left: `${Math.random() * 100}%`,
                top: `-20px`,
                width: `${Math.max(12, Math.random() * 24)}px`,
                height: `${Math.max(12, Math.random() * 24)}px`,
                transform: `rotate(${randomRotation()}deg)`,
                animationDuration: `${5 + Math.random() * 10}s`,
                animationDelay: `${Math.random() * 8}s`,
              }}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default Auth;
