
import React, { useState } from 'react';
import { generateQuestionsFromText, Quiz, generateQuizId } from '@/lib/quiz';
import TextInput from './TextInput';
import QuizComponent from './Quiz';
import QuizResults from './QuizResults';

type AppState = 'input' | 'quiz' | 'results';

const QuizGenerator: React.FC = () => {
  const [appState, setAppState] = useState<AppState>('input');
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  
  const handleTextSubmit = (text: string) => {
    // Generate quiz questions from text
    const questions = generateQuestionsFromText(text);
    
    if (questions.length === 0) {
      // Handle case where no questions could be generated
      console.error('Could not generate questions from the provided text');
      return;
    }
    
    // Create new quiz
    const newQuiz: Quiz = {
      id: generateQuizId(),
      title: `Quiz ${new Date().toLocaleDateString()}`,
      questions,
      createdAt: new Date()
    };
    
    setQuiz(newQuiz);
    setAppState('quiz');
  };
  
  const handleQuizComplete = (completedQuiz: Quiz) => {
    setQuiz(completedQuiz);
    setAppState('results');
  };
  
  const handleRestartQuiz = () => {
    setAppState('input');
    setQuiz(null);
  };
  
  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6 bg-background text-foreground rounded-lg shadow-md">
      {appState === 'input' && (
        <TextInput onSubmit={handleTextSubmit} />
      )}
      
      {appState === 'quiz' && quiz && (
        <QuizComponent quiz={quiz} onComplete={handleQuizComplete} />
      )}
      
      {appState === 'results' && quiz && (
        <QuizResults quiz={quiz} onRestart={handleRestartQuiz} />
      )}
    </div>
  );
};

export default QuizGenerator;
