
import React from 'react';
import { Quiz, calculateScore } from '@/lib/quiz';
import { cn } from '@/lib/utils';
import { fadeIn } from '@/lib/animations';

interface QuizResultsProps {
  quiz: Quiz;
  onRestart: () => void;
}

const QuizResults: React.FC<QuizResultsProps> = ({ quiz, onRestart }) => {
  const { score, total, percentage } = calculateScore(quiz);
  
  // Calculate performance rating
  let performanceMessage = '';
  let performanceClass = '';
  
  if (percentage >= 90) {
    performanceMessage = 'Excellent! You\'ve mastered this material.';
    performanceClass = 'text-green-600';
  } else if (percentage >= 70) {
    performanceMessage = 'Good job! You have a solid understanding.';
    performanceClass = 'text-emerald-600';
  } else if (percentage >= 50) {
    performanceMessage = 'Not bad. Keep reviewing to improve.';
    performanceClass = 'text-amber-600';
  } else {
    performanceMessage = 'You should review this material again.';
    performanceClass = 'text-rose-600';
  }
  
  return (
    <div className={cn("w-full max-w-3xl mx-auto py-8", fadeIn(200))}>
      <div className="bg-white shadow-subtle rounded-xl p-8 overflow-hidden">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-medium mb-2">Quiz Results</h2>
          <p className="text-muted-foreground">Here's how you performed</p>
        </div>
        
        <div className="flex flex-col items-center mb-8">
          <div className="relative w-32 h-32 mb-4">
            <svg className="w-full h-full" viewBox="0 0 100 100">
              <circle
                className="text-secondary"
                strokeWidth="8"
                stroke="currentColor"
                fill="transparent"
                r="40"
                cx="50"
                cy="50"
              />
              <circle
                className="text-primary"
                strokeWidth="8"
                strokeDasharray={`${percentage * 2.51} 251.2`}
                strokeLinecap="round"
                stroke="currentColor"
                fill="transparent"
                r="40"
                cx="50"
                cy="50"
                transform="rotate(-90 50 50)"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center text-2xl font-bold">
              {percentage}%
            </div>
          </div>
          
          <p className="text-lg">
            You got <span className="font-medium">{score}</span> out of <span className="font-medium">{total}</span> questions right.
          </p>
          <p className={cn("text-sm mt-2 font-medium", performanceClass)}>
            {performanceMessage}
          </p>
        </div>
        
        <div className="space-y-6">
          <h3 className="text-lg font-medium border-b pb-2">Review Questions</h3>
          
          {quiz.questions.map((question, index) => {
            const isCorrect = question.userAnswer === question.correctAnswer;
            return (
              <div key={index} className={cn(
                "p-4 rounded-lg",
                isCorrect ? "bg-green-50" : "bg-rose-50",
              )}>
                <p className="font-medium mb-2">{question.text}</p>
                <div className="space-y-1 text-sm">
                  <p>
                    <span className="font-medium">Your answer:</span>{" "}
                    <span className={!isCorrect ? "text-rose-600" : ""}>
                      {question.userAnswer || 'No answer'}
                    </span>
                  </p>
                  {!isCorrect && (
                    <p>
                      <span className="font-medium">Correct answer:</span>{" "}
                      <span className="text-green-600">{question.correctAnswer}</span>
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="mt-8 flex justify-center">
          <button
            onClick={onRestart}
            className={cn(
              "px-6 py-2 rounded-lg bg-primary text-primary-foreground font-medium",
              "hover:bg-primary/90 active:bg-primary/80 transition-all",
              "focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
            )}
          >
            Create New Quiz
          </button>
        </div>
      </div>
    </div>
  );
};

export default QuizResults;
