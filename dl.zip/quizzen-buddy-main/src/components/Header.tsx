
import React from 'react';
import { cn } from '@/lib/utils';

interface HeaderProps {
  className?: string;
}

const Header: React.FC<HeaderProps> = ({ className }) => {
  return (
    <header className={cn("w-full py-6 px-8 flex justify-between items-center", className)}>
      <div className="flex items-center space-x-2">
        <span className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-semibold animate-pulse-slow">
          Q
        </span>
        <span className="text-xl font-medium">QuizzenBuddy</span>
      </div>
      <nav className="hidden md:flex items-center space-x-8">
        <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
          How It Works
        </a>
        <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
          Examples
        </a>
        <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
          About
        </a>
      </nav>
    </header>
  );
};

export default Header;
